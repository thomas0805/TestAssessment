from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta

default_args = {
	'owner' : 'thomas',
	'depends_on_past' : False,
	'start_date' : datetime(2021,12,18),
	'email' : ['thomas@email.com'],
	'email_on_failure' : True,
}

dag = DAG('ETL_job', default_args=default_args, schedule_interval='00 01 * * *')


t1 = BashOperator(
	task_id='dataset_processing',
	bash_command='/opt/anaconda3/bin/python /opt/project/prod/pyfile/ETL.py',
	dag=dag)