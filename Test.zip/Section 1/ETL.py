import pandas as pd
import numpy as np
import time
import glob
import shutil
import os


def read_all_csv (path, delimiter):
    
    filenames = glob.glob(path + "/*.csv")
    df = pd.DataFrame()
    dfs = []
    if not filenames:
        pass
    else:
        for filename in filenames:
            dfs.append(pd.read_csv(filename, sep=delimiter))
        
        df = pd.concat(dfs, ignore_index = True)
    
    return df


def move_to_archive (src_path, archive_path):
    
    today=(time.strftime("%Y-%m-%d"))
    src_path = glob.glob(src_path + "/*.csv")
    archive_path = archive_path + today
    
    if not os.path.exists(archive_path):
        os.mkdir(archive_path)

    for src in src_path:
        archive = archive_path + '/' +src.split('\\')[-1]
        shutil.move(src, archive)


## Data Source
DS_PATH = 'Dataset file path'
DS_ARCHIVE_PATH = 'Archive file Path'
DELIMITER = ','


def ETL():
    # 1. Get contact data from csv file
    df = read_all_csv (DS_PATH, DELIMITER)
   
    if df.empty:
        pass
    else:
        # 2. Transformation
        # Split the name field into first_name, and last_name
        df[['first_name', 'last_name']] = df['name'].loc[df['name'].str.split().str.len() == 2].str.split(expand = True)

        # Delete any rows which do not have a name
        df.dropna(subset = ["name"], inplace=True)

        # Create a new field named above_100, which is true if the price is strictly greater than 100
        df['price'] = df['price'].apply(pd.to_numeric)
        df['above_100'] = np.where(df['price'] > 100, 'True', 'False')
        
         # 3. Move file from inbound to archive after data processing
        move_to_archive (DS_PATH, DS_ARCHIVE_PATH)
        
        # 4. Load 
        df.to_csv('Output file path', index=False)
        
        
ETL()        
