CREATE TABLE car(
	car_id serial PRIMARY KEY,
	manufacturer VARCHAR(255) NULL,
	model_name VARCHAR(255) NULL,
    serial_number VARCHAR(255) NULL,
	weight NUMERIC(16,2) NULL,
	unit_of_mass VARCHAR(10) NULL,
	price  NUMERIC(16,2) NULL
);

CREATE TABLE customer(
	customer_id serial PRIMARY KEY,
	name VARCHAR(255) NULL,
	phone VARCHAR(255) NULL
);

CREATE TABLE sales_person (
	sales_person_id serial PRIMARY KEY,
	name VARCHAR(255) NULL
);


CREATE TABLE transactions (
	transaction_id serial PRIMARY KEY,
	customer_id INT NOT NULL,
	car_id INT NOT NULL,
	sales_person_id INT NOT NULL,
	sales_amount numeric(16,2) NOT NULL,
	transaction_date TIMESTAMP NOT NULL
);